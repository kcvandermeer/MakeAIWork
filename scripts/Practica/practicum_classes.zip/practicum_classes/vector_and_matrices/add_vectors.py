#!/usr/bin/python3

#opdracht: tel twee vectoren bij elkaar op.

# 1. noteer vectorlijst1
# 2. noteer vectorlijst2
# 3 vergelijk of lijsten gelijk zijn
# 4 noteer variabele vector a
# 5 noteer variabele vector b
# 6 maak een lijs van vector a
# 7 maak een lijs van vector b
# 8 maak de som van lijst van beide vectoren
# 9 creeer de som

# def somOfVectors

def sumOfVectors (a,b):
    # HIER VERDER GAAN for sumOfVectors (a,b)
    c = [a[0] + b[0], a[1] + b[1], a[2] + b [2]]
    return c

a = [0,3,1]
b = [1,4,7]
c = sumOfVectors(a,b)


print (sumOfVectors(a,b))





