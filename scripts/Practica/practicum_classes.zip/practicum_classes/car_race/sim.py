# from file import class
from world import World

# created instance of World class
world = World()

world.bang()
# world.stop()